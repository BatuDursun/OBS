﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ObsWebApp
{
    public partial class Login : System.Web.UI.Page
    {
        // SQL Server bağlantısı için SqlConnection nesnesi oluşturuluyor.
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-2C82G8P;Initial Catalog=AtaturkOgrenci;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklenirken yapılacak işlemler buraya yazılabilir.
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Ogrenci giriş butonuna tıklandığında gerçekleşecek işlemler
            baglanti.Open();
            SqlCommand komut = new SqlCommand("Select * from Tbl_Ogrenci where Ogr_Numara = @p1 and Ogr_Sifre = @p2", baglanti);
            komut.Parameters.AddWithValue("@p1", txtKullanıcı.Text);
            komut.Parameters.AddWithValue("@p2", txtSifre.Text);
            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {
                // Giriş başarılıysa öğrenci numarası Session'a eklenir ve öğrenci ana sayfasına yönlendirilir.
                Session.Add("Ogr_Numara", txtKullanıcı.Text);
                Response.Redirect("ogrenciDefault.Aspx");
            }
            else
            {
                // Giriş başarısızsa kullanıcıya hata mesajı gösterilir.
                Label1.Text = "Lütfen tekrar deneyiniz.";
            }

            baglanti.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            // Ogretmen giriş butonuna tıklandığında gerçekleşecek işlemler
            baglanti.Open();
            SqlCommand komut = new SqlCommand("Select * from Tbl_Ogretmen where Ogretmen_Numara = @p1 and Ogretmen_Sifre = @p2", baglanti);
            komut.Parameters.AddWithValue("@p1", txtKullanıcı.Text);
            komut.Parameters.AddWithValue("@p2", txtSifre.Text);
            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {
                // Giriş başarılıysa öğretmen numarası Session'a eklenir ve öğretmen ana sayfasına yönlendirilir.
                Session.Add("Ogretmen_Numara", txtKullanıcı.Text);
                Response.Redirect("Default.Aspx");
            }
            else
            {
                // Giriş başarısızsa kullanıcıya hata mesajı gösterilir.
                Label1.Text = "Lütfen tekrar deneyiniz.";
            }

            baglanti.Close();
        }
    }
}
