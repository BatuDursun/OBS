﻿//------------------------------------------------------------------------------
// <otomatik üretildi>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler yanlış davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik üretildi>
//------------------------------------------------------------------------------

namespace ObsWebApp
{


	public partial class OgrenciBul
	{

		/// <summary>
		/// Form1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm Form1;

		/// <summary>
		/// txtOgrNumara denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtOgrNumara;

		/// <summary>
		/// Label7 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label7;

		/// <summary>
		/// Label2 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label2;

		/// <summary>
		/// Label11 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label11;

		/// <summary>
		/// Label3 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label3;

		/// <summary>
		/// Label8 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label8;

		/// <summary>
		/// Label4 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label4;

		/// <summary>
		/// Label9 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label9;

		/// <summary>
		/// Label5 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label5;

		/// <summary>
		/// Label10 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label10;

		/// <summary>
		/// Label6 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label6;

		/// <summary>
		/// Button1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button Button1;
	}
}
