﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class OgrenciBul : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Tbl_OgrenciTableAdapter ile öğrenci bilgilerini bulma işlemi gerçekleştiriliyor.
            DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();

            // Öğrenci numarası kullanılarak öğrenci bilgileri çekiliyor ve ekrandaki Label kontrollerine atanıyor.
            Label2.Text = dt.OgrenciBul(txtOgrNumara.Text.ToString())[0].Ogr_Ad;
            Label3.Text = dt.OgrenciBul(txtOgrNumara.Text.ToString())[0].Ogr_Soyad;
            Label4.Text = dt.OgrenciBul(txtOgrNumara.Text.ToString())[0].Ogr_Telefon;
            Label5.Text = dt.OgrenciBul(txtOgrNumara.Text.ToString())[0].Ogr_Mail;
            Label6.Text = dt.OgrenciBul(txtOgrNumara.Text.ToString())[0].Ogr_Sifre;
        }
    }
}
