﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ObsWebApp
{
    public partial class NotGüncelle : System.Web.UI.Page
    {
        // SQL Server bağlantısı için SqlConnection nesnesi oluşturuluyor.
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-2C82G8P;Initial Catalog=AtaturkOgrenci;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde ve sayfa yeniden yüklenmediyse (postback değilse) çalışacak kod bloğu
            if (!Page.IsPostBack)
            {
                // QueryString üzerinden gelen BenzersizID değeri alınıyor.
                int nid = Convert.ToInt32(Request.QueryString["BenzersizID"].ToString());

                // Ogr_NotlariTableAdapter ile ilgili notun bilgileri çekilip TextBox'lara atanıyor.
                DataSet1TableAdapters.Ogr_NotlariTableAdapter dt = new DataSet1TableAdapters.Ogr_NotlariTableAdapter();
                DataRow notBilgisi = dt.NotGetir2(nid)[0];

                // TextBox'lara veriler atanıyor.
                txtOgrID.Text = notBilgisi["Ogr_ID"].ToString();
                txtOgrAdSoyad.Text = notBilgisi["Ad Soyad"].ToString();
                txtDersAd.Text = notBilgisi["Ders_Ad"].ToString();
                txtOgrVize.Text = notBilgisi["Vize"].ToString();
                txtOgrFinal.Text = notBilgisi["Final"].ToString();
                txtOgrOrt.Text = notBilgisi["Ortalama"].ToString();
                txtDurum.Text = notBilgisi["Durum"].ToString();
            }
        }

        protected void BtnHesapla_Click(object sender, EventArgs e)
        {
            // Vize ve Final puanlarına göre ortalama hesaplanıp TextBox'lara atanıyor.
            int vize = Convert.ToInt32(txtOgrVize.Text);
            int final = Convert.ToInt32(txtOgrFinal.Text);

            // Bağlantı açılıyor.
            baglanti.Open();

            // OrtalamaAl Fonksiyonu kullanılarak ortalamayı hesaplamak üzere SqlCommand nesnesi oluşturuluyor.
            SqlCommand komut = new SqlCommand("SELECT dbo.OrtalamaAl(@Vize, @Final) AS Ortalama", baglanti);
            komut.Parameters.AddWithValue("@Vize", vize);
            komut.Parameters.AddWithValue("@Final", final);

            // SqlDataReader ile veri okuma işlemi gerçekleştiriliyor.
            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {
                // Okunan ortalama değeri TextBox'a atanıyor.
                decimal ortalama = Convert.ToDecimal(dr["Ortalama"]);
                txtOgrOrt.Text = ortalama.ToString("0.00");

                // Ortalama puanına göre durum belirlenip TextBox'a atanıyor.
                bool durum = ortalama >= 45;
                txtDurum.Text = durum.ToString();
            }

            // Bağlantı kapatılıyor.
            baglanti.Close();
        }

        protected void BtnGuncelle_Click(object sender, EventArgs e)
        {
            // QueryString üzerinden gelen BenzersizID değeri alınıyor.
            int nid = Convert.ToInt32(Request.QueryString["BenzersizID"].ToString());

            // Ogr_NotlariTableAdapter ile not güncelleme işlemi gerçekleştiriliyor.
            DataSet1TableAdapters.Ogr_NotlariTableAdapter dt = new DataSet1TableAdapters.Ogr_NotlariTableAdapter();

            // TextBox'lardan alınan değerlerle NotGuncelle metodu çağrılıyor.
            dt.NotGuncelle(byte.Parse(txtOgrVize.Text), byte.Parse(txtOgrFinal.Text), decimal.Parse(txtOgrOrt.Text), bool.Parse(txtDurum.Text), nid);

            // Not güncelleme işlemi tamamlandıktan sonra kullanıcıyı "NotListesi.aspx" sayfasına yönlendir.
            Response.Redirect("NotListesi.aspx");
        }
    }
}
