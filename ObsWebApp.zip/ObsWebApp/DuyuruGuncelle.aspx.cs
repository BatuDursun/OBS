﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class DuyuruGuncelle : System.Web.UI.Page
    {
        int id;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde ve sayfa yeniden yüklenmediyse (postback değilse) çalışacak kod bloğu
            if (Page.IsPostBack == false)
            {
                // QueryString üzerinden gelen Duyuru_ID değeri alınıyor.
                id = Convert.ToInt32(Request.QueryString["Duyuru_ID"].ToString());

                // Tbl_DuyurularTableAdapter ile ilgili duyurunun bilgileri çekilip TextBox ve TextArea'ya atanıyor.
                DataSet1TableAdapters.Tbl_DuyurularTableAdapter dt = new DataSet1TableAdapters.Tbl_DuyurularTableAdapter();
                txtDuyuru_ID.Text = id.ToString();
                txtDuyuruBaslik.Text = dt.DuyuruSec(id)[0].Duyuru_Baslık;
                TextArea1.Value = dt.DuyuruSec(id)[0].Duyuru_İcerik;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Duyuru güncelleme işlemi için Tbl_DuyurularTableAdapter kullanılıyor.
            DataSet1TableAdapters.Tbl_DuyurularTableAdapter dt = new DataSet1TableAdapters.Tbl_DuyurularTableAdapter();

            // Güncellenen duyuru başlık, içerik ve duyuru ID'si ile DuyuruGuncelle metodu çağrılıyor.
            dt.DuyuruGuncelle(txtDuyuruBaslik.Text, TextArea1.Value, Convert.ToInt32(txtDuyuru_ID.Text));

            // Duyuru güncelleme işlemi tamamlandıktan sonra kullanıcıyı "DuyuruListesi.aspx" sayfasına yönlendir.
            Response.Redirect("DuyuruListesi.aspx");
        }
    }
}
