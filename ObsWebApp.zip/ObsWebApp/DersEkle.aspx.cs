﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
	public partial class DersEkle : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void Button1_Click(object sender, EventArgs e)
		{
			// Tbl_Dersler tablosuna yeni bir ders eklemek için Tbl_DerslerTableAdapter kullanılıyor.
			DataSet1TableAdapters.Tbl_DerslerTableAdapter dt = new DataSet1TableAdapters.Tbl_DerslerTableAdapter();

			// Eklenen dersin adı, TextBox'tan alınarak Tbl_DerslerTableAdapter'ın DersEkle metoduyla ekleniyor.
			dt.DersEkle(txtDers.Text);

			// Ders ekleme işlemi tamamlandıktan sonra kullanıcıyı "DersListesi.aspx" sayfasına yönlendir.
			Response.Redirect("DersListesi.aspx");

		}
	}
}