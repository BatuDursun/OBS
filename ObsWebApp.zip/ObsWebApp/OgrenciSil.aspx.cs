﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class OgrenciSil : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            // QueryString üzerinden alınan öğrenci ID'si
            int id = Convert.ToInt32(Request.QueryString["Ogr_ID"].ToString());

            // Tbl_OgrenciTableAdapter ile öğrenci silme işlemi yapılıyor
            DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();
            dt.ogrenciSil(id);

            // Öğrenci silme işlemi tamamlandıktan sonra ana sayfaya yönlendirme yapılıyor
            Response.Redirect("Default.aspx");
        }
    }
}
