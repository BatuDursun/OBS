﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class OgrenciPanelGuncelle : System.Web.UI.Page
    {
        int id;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            // QueryString üzerinden alınan öğrenci numarası TextBox'a atanıyor
            txtBox1.Text = Request.QueryString["Ogr_Numara"];
            int ogrNumara = Convert.ToInt32(txtBox1.Text);

            if (Page.IsPostBack == false)
            {
                // Sayfa ilk kez yüklendiğinde çalışacak olan kod bloğu
                // Burada gerekirse başka başlangıç ayarları yapılabilir.
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // "Güncelle" butonuna tıklandığında çalışacak olan kod bloğu

            // Tbl_OgrenciTableAdapter ile öğrenci şifresi değiştirme işlemi yapılıyor
            DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();

            // Yeni şifre ve tekrar şifre alanlarının karşılaştırılması
            if (TextBox9.Text != TextBox8.Text)
            {
                Label1.Text = "Şifreler Aynı Olmalıdır!";
                TextBox9.Text = "";
                TextBox8.Text = "";
            }
            else
            {
                // Yeni şifre, öğrenci numarası üzerinden güncelleniyor
                dt.OgrenciSifreDegistir(TextBox9.Text, txtBox1.Text);

                // Şifre güncelleme işlemi başarılıysa mesaj gösterilip, sayfa yeniden yönlendiriliyor
                Label1.Text = "Şifreniz Güncellendi! Yeni Şifreniz: " + TextBox9.Text;
                TextBox9.Text = "";
                TextBox8.Text = "";
                Response.Redirect("ogrenciDefault.aspx?Ogr_Numara=" + txtBox1.Text);
            }
        }
    }
}
