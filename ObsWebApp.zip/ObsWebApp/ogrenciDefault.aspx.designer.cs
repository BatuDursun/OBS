﻿//------------------------------------------------------------------------------
// <otomatik üretildi>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler yanlış davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik üretildi>
//------------------------------------------------------------------------------

namespace ObsWebApp
{


	public partial class ogrenciDefault
	{

		/// <summary>
		/// Form1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm Form1;

		/// <summary>
		/// txtBox1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtBox1;

		/// <summary>
		/// TextBox2 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox TextBox2;

		/// <summary>
		/// TextBox3 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox TextBox3;

		/// <summary>
		/// TextBox4 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox TextBox4;

		/// <summary>
		/// TextBox5 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox TextBox5;

		/// <summary>
		/// TextBox6 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox TextBox6;

		/// <summary>
		/// TextBox7 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox TextBox7;

		/// <summary>
		/// Button1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button Button1;
	}
}
