﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class DersGuncelle : System.Web.UI.Page
    {
        int id;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde ve sayfa yeniden yüklenmediyse (postback değilse) çalışacak kod bloğu
            if (Page.IsPostBack == false)
            {
                // QueryString üzerinden gelen Ders_ID değeri alınıyor.
                id = Convert.ToInt32(Request.QueryString["Ders_ID"].ToString());

                // Tbl_DerslerTableAdapter ile ilgili dersin bilgileri çekilip TextBox'lara atanıyor.
                DataSet1TableAdapters.Tbl_DerslerTableAdapter dt = new DataSet1TableAdapters.Tbl_DerslerTableAdapter();
                txtDersID.Text = id.ToString();
                txtDersAdı.Text = dt.DersSec(id)[0].Ders_Ad;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Ders güncelleme işlemi için Tbl_DerslerTableAdapter kullanılıyor.
            DataSet1TableAdapters.Tbl_DerslerTableAdapter dt = new DataSet1TableAdapters.Tbl_DerslerTableAdapter();

            // Güncellenen ders adı ve ders ID'si ile DersGuncelle metodu çağrılıyor.
            dt.DersGuncelle(txtDersAdı.Text, Convert.ToInt32(txtDersID.Text));

            // Ders güncelleme işlemi tamamlandıktan sonra kullanıcıyı "DersListesi.aspx" sayfasına yönlendir.
            Response.Redirect("DersListesi.aspx");
        }
    }
}
