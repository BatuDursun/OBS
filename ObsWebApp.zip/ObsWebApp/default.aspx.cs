﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu
            // Tbl_Ogrenci tablosunu listeleyen bir Repeater kontrolüne veri bağlanıyor.
            DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();
            Repeater1.DataSource = dt.OgrenciListesi();
            Repeater1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // "SilinenOgrenciler.aspx" sayfasına yönlendiren buton click olayı
            Response.Redirect("SilinenOgrenciler.aspx");
        }
    }
}
