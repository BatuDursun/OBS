﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class NotListesi : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            // Ogr_NotlariTableAdapter ile notları getirme işlemi gerçekleştiriliyor.
            DataSet1TableAdapters.Ogr_NotlariTableAdapter dt = new DataSet1TableAdapters.Ogr_NotlariTableAdapter();

            // Repeater kontrolünde Ogr_Notlari SP kullanımı
            Repeater1.DataSource = dt.NotlariGetir();
            Repeater1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // "DerstenKalanlar.aspx" sayfasına yönlendirme işlemi gerçekleştiriliyor.
            Response.Redirect("DerstenKalanlar.aspx");
        }
    }
}
