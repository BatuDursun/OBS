﻿//------------------------------------------------------------------------------
// <otomatik üretildi>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler yanlış davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik üretildi>
//------------------------------------------------------------------------------

namespace ObsWebApp
{


	public partial class MesajOlustur
	{

		/// <summary>
		/// Form1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm Form1;

		/// <summary>
		/// txtGonderen denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtGonderen;

		/// <summary>
		/// txtAlici denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtAlici;

		/// <summary>
		/// txtBaslık denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtBaslık;

		/// <summary>
		/// txtIcerik denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlTextArea txtIcerik;

		/// <summary>
		/// btnGonder denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button btnGonder;
	}
}
