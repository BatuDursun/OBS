﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ObsWebApp
{
    
        public partial class İstatistikler : Page
        {
            protected void Page_Load(object sender, EventArgs e)
            {
                DataSet1TableAdapters.Tbl_Ogrenci1TableAdapter dt = new
                    DataSet1TableAdapters.Tbl_Ogrenci1TableAdapter();
                txtBox1.Text = "Toplam Öğrenci Sayısı: " + dt.İstatistik1().ToString();
                TextBox2.Text = "Toplam Öğretmen Sayısı: " + dt.İstatistik2().ToString();
                TextBox3.Text = "Toplam Ders Sayısı:" + dt.İstatistik3().ToString();
                TextBox4.Text = "Vizesi En Yüksek Öğrenci: " + dt.İstatistik4().ToString(); //vizedeEnBasariliOgrenci SP kullanımı
                // TextBox5.Text = "Finali En Yüksek Öğrenci: " + dt.İstatistik5().ToString();
                TextBox6.Text = "Bütün Vizelerin Ortalaması: " + dt.İstatistik6().ToString();
                TextBox7.Text = "Bütün Finallerin Ortalaması: " + dt.İstatistik7().ToString();

                if (!IsPostBack)
                {
                    // Veritabanı bağlantı dizesi
                    string connectionString = "Data Source=DESKTOP-2C82G8P;Initial Catalog=AtaturkOgrenci;Integrated Security=True";

                    // SqlConnection ve SqlCommand kullanarak veritabanına bağlanma
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        // En yüksek final alan öğrenci numarasını almak için fonksiyon kullanma
                        string query = "SELECT dbo.EnYuksekFinalAlanOgrenciNumarası() AS EnYuksekFinalAlanOgrenciNumara";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // SqlDataReader kullanarak sorguyu çalıştırma
                            SqlDataReader reader = command.ExecuteReader();

                            if (reader.Read())
                            {
                                // TextBox5 içine değeri yerleştirme
                                TextBox5.Text = "Finali En Yüksek Öğrencinin Numarası: " + reader["EnYuksekFinalAlanOgrenciNumara"].ToString();
                            }
                        }
                    }
                }
            }
        }
}

