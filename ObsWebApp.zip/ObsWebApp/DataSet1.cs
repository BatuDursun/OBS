﻿namespace ObsWebApp
{


	partial class DataSet1
	{
	}
}
