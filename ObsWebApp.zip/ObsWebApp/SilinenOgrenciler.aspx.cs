﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
	public partial class SilinenOgrenciler : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

			// Sayfa yüklendiğinde çalışacak olan kod bloğu

			// SilinenOgrencilerTablosuTableAdapter ile silinen öğrencilerin bilgilerini getirme işlemi yapılıyor
			DataSet1TableAdapters.SilinenOgrencilerTablosuTableAdapter dt = new DataSet1TableAdapters.SilinenOgrencilerTablosuTableAdapter();

			// Repeater kontrolüne veri kaynağını set ederek silinen öğrencilerin bilgilerini ekrana yazdırma
			Repeater1.DataSource = dt.SilinenOgrencileriGetir();
			Repeater1.DataBind();

		}

		protected void Button1_Click(object sender, EventArgs e)
		{
			
		}
	}
}