﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
	public partial class DuyuruSil : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			int id =Convert.ToInt32(Request.QueryString["Duyuru_ID"].ToString());
			DataSet1TableAdapters.Tbl_DuyurularTableAdapter dt = new DataSet1TableAdapters.Tbl_DuyurularTableAdapter();

			dt.DuyuruSil(id);
			Response.Redirect("DuyuruListesi.Aspx");
			
		}
	}
}