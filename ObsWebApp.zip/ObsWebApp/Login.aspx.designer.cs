﻿//------------------------------------------------------------------------------
// <otomatik üretildi>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler yanlış davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik üretildi>
//------------------------------------------------------------------------------

namespace ObsWebApp
{


	public partial class Login
	{

		/// <summary>
		/// form1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm form1;

		/// <summary>
		/// Image1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Image Image1;

		/// <summary>
		/// Label1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label Label1;

		/// <summary>
		/// txtKullanıcı denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtKullanıcı;

		/// <summary>
		/// txtSifre denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtSifre;

		/// <summary>
		/// Button1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button Button1;

		/// <summary>
		/// Button2 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button Button2;
	}
}
