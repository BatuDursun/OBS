﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ObsWebApp
{
    public partial class Grafikler : System.Web.UI.Page
    {
        // SQL Server bağlantısı için SqlConnection nesnesi oluşturuluyor.
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-2C82G8P;Initial Catalog=AtaturkOgrenci;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            // İlk grafik için SQL komutu ile Grafik 1 SP'si çalıştırılıp, veritabanından alınan verilerle Chart1 kontrolüne veri ekleniyor.
            baglanti.Open();
            SqlCommand komut = new SqlCommand("Execute Grafik1", baglanti);
            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {
                Chart1.Series["Dersler"].Points.AddXY(Convert.ToString(dr[0]), int.Parse(dr[1].ToString()));
            }
            baglanti.Close();

            // İkinci grafik içinSQL komutu ile Grafik 2 SP'si çalıştırılıp, veritabanından alınan verilerle Chart1 kontrolüne veri ekleniyor.
            baglanti.Open();
            SqlCommand komut2 = new SqlCommand("Execute Grafik2", baglanti);
            SqlDataReader dr2 = komut2.ExecuteReader();
            while (dr2.Read())
            {
                Chart3.Series["Ders Adı"].Points.AddXY(Convert.ToString(dr2[0]), int.Parse(dr2[1].ToString()));
            }
            baglanti.Close();
        }
    }
}
