﻿//------------------------------------------------------------------------------
// <otomatik üretildi>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler yanlış davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik üretildi>
//------------------------------------------------------------------------------

namespace ObsWebApp
{


	public partial class NotGüncelle
	{

		/// <summary>
		/// Form1 denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm Form1;

		/// <summary>
		/// txtDersAd denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtDersAd;

		/// <summary>
		/// txtOgrID denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtOgrID;

		/// <summary>
		/// txtOgrAdSoyad denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtOgrAdSoyad;

		/// <summary>
		/// txtOgrVize denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtOgrVize;

		/// <summary>
		/// txtOgrFinal denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtOgrFinal;

		/// <summary>
		/// txtOgrOrt denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtOgrOrt;

		/// <summary>
		/// txtDurum denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox txtDurum;

		/// <summary>
		/// BtnHesapla denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button BtnHesapla;

		/// <summary>
		/// BtnGuncelle denetimi.
		/// </summary>
		/// <remarks>
		/// Otomatik üretilmiş alan.
		/// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button BtnGuncelle;
	}
}
