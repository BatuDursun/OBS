﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class OgrenciMesajOlustur : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            // Oturumdan alınan öğrenci numarası ile gönderen TextBox'un değeri atanıyor
            txtGonderen.Text = Session["Ogr_Numara"].ToString();
        }

        protected void btnGonder_Click(object sender, EventArgs e)
        {
            // "Gönder" butonuna tıklandığında çalışacak olan kod bloğu

            // Tbl_MesajlarTableAdapter ile mesaj gönderme işlemi yapılıyor
            DataSet1TableAdapters.Tbl_MesajlarTableAdapter dt = new DataSet1TableAdapters.Tbl_MesajlarTableAdapter();
            dt.MesajGonder(txtGonderen.Text, txtAlici.Text, txtBaslık.Text, txtIcerik.Value.ToString());

            // Mesaj gönderildikten sonra öğrenci giden mesajlar sayfasına yönlendirme yapılıyor
            Response.Redirect("OgrenciGidenMesajlar.aspx");
        }
    }
}
