﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;



namespace ObsWebApp
{
    public partial class OgrenciEkle : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Öğrenci numarasını al
            string ogrNumara = txtOgrNum.Text;

            // Veritabanı bağlantı dizesi
            string connectionString = "Data Source=DESKTOP-2C82G8P;Initial Catalog=AtaturkOgrenci;Integrated Security=True";

           
            
                // SqlConnection ve SqlCommand kullanarak veritabanına bağlanma
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                //ogrenciKontrol Fonksiyon kullanımı
                using (SqlCommand cmdOgrenciKontrol = new SqlCommand("SELECT dbo.ogrenciKontrol(@Ogr_Numara)", connection))
                    {
                        cmdOgrenciKontrol.Parameters.AddWithValue("@Ogr_Numara", ogrNumara);

                    
                    bool ogrenciVarMi = (bool)cmdOgrenciKontrol.ExecuteScalar();

                        if (ogrenciVarMi)//ogrenciKontrol Fonksiyonu ile öğrenci varsa eğer bu kısıma girer ve hata mesajını ekrana yazdırır eğer yoksa else kısımından devam eder.
                             {
                            // Uyarı mesajını ekrana yazdırma
                            Label1.Text = "Bu öğrenci numarası zaten sistemde kayıtlı.";
                        }
                        else
                        {

                            if (ogrNumara.Length <= 5) // Sütunun tanımlı boyutunu kontrol et
                            {
                                // Ogr_Kaydet SP kullanımı
                                DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();
                                dt.Ogr_Kaydet(txtOgrAd.Text, txtOgrSoyad.Text, txtOgrTelefon.Text, txtOgrMail.Text, txtOgrSifre.Text, txtOgrFoto.Text, ogrNumara);

                                Label1.Text = "Öğrenci Başarıyla Eklendi.";
                                Response.Redirect("default.aspx");
                            }
                            else
                            {
                                Label1.Text = "Öğrenci numarası 5 haneli veya daha az olmalıdır!";
                            }
                        }
                    }
                    
                    
                }
        }

    }
}







