﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class ogrenciDefault : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            // Oturumdan alınan öğrenci numarası ile öğrenci bilgileri çekiliyor.
            txtBox1.Text = Session["Ogr_Numara"].ToString();
            DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();

            // Çekilen bilgiler TextBox kontrollerine atanıyor.
            TextBox2.Text = "Adınız: " + dt.OgrenciPaneliGetir(txtBox1.Text)[0].Ogr_Ad;
            TextBox3.Text = "Soyadınız: " + dt.OgrenciPaneliGetir(txtBox1.Text)[0].Ogr_Soyad;
            TextBox4.Text = "Telefon Numaranız: " + dt.OgrenciPaneliGetir(txtBox1.Text)[0].Ogr_Telefon;
            TextBox5.Text = "Mail Adresiniz: " + dt.OgrenciPaneliGetir(txtBox1.Text)[0].Ogr_Mail;
            TextBox6.Text = "Fotoğrafınız: " + dt.OgrenciPaneliGetir(txtBox1.Text)[0].Ogr_Fotograf;
            TextBox7.Text = "Şifreniz: " + dt.OgrenciPaneliGetir(txtBox1.Text)[0].Ogr_Sifre;
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            // "OgrenciPanelGuncelle.aspx" sayfasına öğrenci numarası parametresi ile yönlendirme işlemi gerçekleştiriliyor.
            Response.Redirect("OgrenciPanelGuncelle.aspx?Ogr_Numara=" + txtBox1.Text);
        }
    }
}
