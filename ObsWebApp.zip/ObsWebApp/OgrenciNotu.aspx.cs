﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
	public partial class OgrenciNotu : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

			DataSet1TableAdapters.Ogr_NotlariTableAdapter dt = new DataSet1TableAdapters.Ogr_NotlariTableAdapter();
			Repeater1.DataSource = dt.OgrenciNotu(Session["Ogr_Numara"].ToString());
			Repeater1.DataBind();
			
		}
	}
}