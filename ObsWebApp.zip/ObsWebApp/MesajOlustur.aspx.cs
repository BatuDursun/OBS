﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class MesajOlustur : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu
            // Kullanıcının oturumu açıkken, oturumdan alınan Ogretmen_Numara değeri Gonderen TextBox'ına atanıyor.
            txtGonderen.Text = Session["Ogretmen_Numara"].ToString();
        }

        protected void btnGonder_Click(object sender, EventArgs e)
        {
            // Mesaj gönderme işlemi için Tbl_MesajlarTableAdapter kullanılıyor.
            DataSet1TableAdapters.Tbl_MesajlarTableAdapter dt = new DataSet1TableAdapters.Tbl_MesajlarTableAdapter();

            // TextBox, TextArea ve oturumdan alınan değerlerle MesajGonder metodu çağrılıyor.
            dt.MesajGonder(txtGonderen.Text, txtAlici.Text, txtBaslık.Text, txtIcerik.Value.ToString());

            // Mesaj gönderme işlemi tamamlandıktan sonra kullanıcıyı "GidenMesajlar.aspx" sayfasına yönlendir.
            Response.Redirect("GidenMesajlar.aspx");
        }
    }
}
