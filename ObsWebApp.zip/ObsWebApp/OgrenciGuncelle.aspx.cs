﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ObsWebApp
{
    public partial class OgrenciGuncelle : System.Web.UI.Page
    {
        int id;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde çalışacak olan kod bloğu

            if (Page.IsPostBack == false)
            {
                // Postback olmadığında (sayfa ilk kez yüklendiğinde) çalışacak kod bloğu

                // QueryString'den öğrenci ID'sini al
                id = Convert.ToInt32(Request.QueryString["Ogr_ID"].ToString());
                txtOgrID.Text = id.ToString();

                // Tbl_OgrenciTableAdapter ile öğrenci bilgilerini çek
                DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();

                // TextBox kontrollerine çekilen bilgileri ata
                txtOgrAd.Text = dt.OgrenciSec(id)[0].Ogr_Ad;
                txtOgrSoyad.Text = dt.OgrenciSec(id)[0].Ogr_Soyad;
                txtOgrMail.Text = dt.OgrenciSec(id)[0].Ogr_Mail;
                txtOgrTelefon.Text = dt.OgrenciSec(id)[0].Ogr_Telefon;
                txtOgrSifre.Text = dt.OgrenciSec(id)[0].Ogr_Sifre;
                txtOgrFoto.Text = dt.OgrenciSec(id)[0].Ogr_Fotograf;
                txtOgrNum.Text = dt.OgrenciSec(id)[0].Ogr_Numara;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Butona tıklandığında çalışacak olan kod bloğu

            // Öğrenci numarasını al
            string ogrNumara = txtOgrNum.Text;

            // Veritabanı bağlantı dizesi
            string connectionString = "Data Source=DESKTOP-2C82G8P;Initial Catalog=AtaturkOgrenci;Integrated Security=True";

            // SqlConnection ve SqlCommand kullanarak veritabanına bağlanma
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // ogrenciKontrol ile öğrenci numarasının kontrolü
                using (SqlCommand cmdOgrenciKontrol = new SqlCommand("SELECT dbo.ogrenciKontrol(@Ogr_Numara)", connection))
                {
                    cmdOgrenciKontrol.Parameters.AddWithValue("@Ogr_Numara", ogrNumara);

                    // Öğrenci numarasının geçerliliğini kontrol et
                    bool ogrenciVarMi = (bool)cmdOgrenciKontrol.ExecuteScalar();
            
                {

                    
                    
                        // Ogr_Guncelle SP kullanımı
                        DataSet1TableAdapters.Tbl_OgrenciTableAdapter dt = new DataSet1TableAdapters.Tbl_OgrenciTableAdapter();
                        dt.Ogr_Guncelle(txtOgrAd.Text, txtOgrSoyad.Text, txtOgrTelefon.Text, txtOgrMail.Text, txtOgrSifre.Text, txtOgrFoto.Text, txtOgrNum.Text, Convert.ToInt32(txtOgrID.Text));

                        // Kullanıcıya başarılı güncelleme mesajını göster
                        Label1.Text = "Öğrenci Başarıyla Güncellendi.";

                        // Ana sayfaya yönlendir
                        Response.Redirect("Default.aspx");
                        Label1.Text = "Öğrenci numarası 5 haneli veya daha az olmalıdır!";
                    
                }
                }
            }
        }
    }
}

