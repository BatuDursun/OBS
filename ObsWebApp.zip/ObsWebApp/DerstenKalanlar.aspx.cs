﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
	public partial class DerstenKalanlar : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

			// Sayfa yüklendiğinde çalışacak olan kod bloğu
			// Tbl_Kalanlar tablosunu listeleyen bir Repeater kontrolüne veri bağlanıyor.
			DataSet1TableAdapters.Tbl_KalanlarTableAdapter dt = new DataSet1TableAdapters.Tbl_KalanlarTableAdapter();
			Repeater1.DataSource = dt.KalanlarıGetir();
			Repeater1.DataBind();
		}
	}
}