﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ObsWebApp
{
    public partial class DuyuruEkle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Sayfa yüklendiğinde ve sayfa yeniden yüklenmediyse (postback değilse) çalışacak kod bloğu
            if (Page.IsPostBack == false)
            {
                // Tbl_OgretmenTableAdapter ile öğretmen listesi alınıp DropDownList'e bağlanıyor.
                DataSet1TableAdapters.Tbl_OgretmenTableAdapter dt = new DataSet1TableAdapters.Tbl_OgretmenTableAdapter();
                DropDownList1.DataSource = dt.OgretmenListesi();
                DropDownList1.DataTextField = "Ad Soyad";
                DropDownList1.DataValueField = "Ogretmen_ID";
                DropDownList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Duyuru ekleme işlemi için Tbl_DuyurularTableAdapter kullanılıyor.
            DataSet1TableAdapters.Tbl_DuyurularTableAdapter dt = new DataSet1TableAdapters.Tbl_DuyurularTableAdapter();

            // TextBox, TextArea ve DropDownList üzerinden alınan verilerle DuyuruEkle metodu çağrılıyor.
            dt.DuyuruEkle(txtDuyuruBaslik.Text, TextArea1.Value.ToString(), Convert.ToInt32(DropDownList1.SelectedValue));

            // Duyuru ekleme işlemi tamamlandıktan sonra kullanıcıyı "DuyuruListesi.aspx" sayfasına yönlendir.
            Response.Redirect("DuyuruListesi.aspx");
        }
    }
}
